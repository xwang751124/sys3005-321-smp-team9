export interface Attributes {
	productId: number;
}
