export const blockAttributes: Record< string, Record< string, unknown > > = {
	productId: {
		type: 'number',
		default: 0,
	},
};

export default blockAttributes;
