export const STORE_KEY = 'wc/store/query-state';
