<?php

//Begin Really Simple SSL session cookie settings
@ini_set('session.cookie_httponly', true);
@ini_set('session.cookie_secure', true);
@ini_set('session.use_only_cookies', true);
//END Really Simple SSL
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'refondsp_wp86' );

/** MySQL database username */
define( 'DB_USER', 'refondsp_wp86' );

/** MySQL database password */
define( 'DB_PASSWORD', '7P2(-p]3SIGI)]X4' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'cdalm7dx13yvsfwdp01a206ca98eurkrceckyjoykoq4hyzawq0hk6ie1abea7lp' );
define( 'SECURE_AUTH_KEY',  'u3ehmh71npsa26oh1u4drspxypvepspxu3wglwa3vd5nlghiu67cq4mw6fwzmie6' );
define( 'LOGGED_IN_KEY',    'vsn172fqqhdxkjwucmbcxyaczpspnugpojxigy8rfgfmmk7sqcny4qn17g5inlvm' );
define( 'NONCE_KEY',        'gu4ynvljpepvdigyqj8fbc6r6l59g4e6xjbkcsduuffzztcu8ydvupd1h5x5o8jw' );
define( 'AUTH_SALT',        'cpjwljd2m1nfdichnrqo8cq37wdwat79m7ay7giluuxcly828ilt6frvwtbnrggn' );
define( 'SECURE_AUTH_SALT', 'nohr4ecnalsnrxtjvsb0wrnl61fccfs94trkgp4f0nillljetxlvd7ttvjimxifn' );
define( 'LOGGED_IN_SALT',   'ikltfnmpfyptbv8pkiw6fc0o0wktqxyl79xd0rvhdnfww47xpibqhwqkaa6ogmqx' );
define( 'NONCE_SALT',       '3c5snlwfnpuyapqcjhirqgjcb37lk9vintihw6mnb11t1nlq9hjqoi70kdu0q4mm' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpkx_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
